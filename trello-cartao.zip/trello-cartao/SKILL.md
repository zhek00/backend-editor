---
name: trello-cartao
description: Use sempre que o usuário mandar um título de vídeo e um link (do YouTube ou outro), mesmo sem pedir nada: cria um cartão no quadro "youtube" do Trello, na coluna do canal certo, deduzida pelo assunto e pelo idioma do título.
---

# Cartão no Trello com título e link

Quando o usuário mandar um título e um link (ex.: `Os 10 Insetos Mais Venenosos — https://youtube.com/...`),
crie um cartão no Trello sem perguntar. Nome do cartão = o título, exatamente como veio. Descrição = o link.

Quadro: **youtube** (https://trello.com/b/7MAyqN4o/youtube)
`ari:cloud:trello::board/workspace/6aa6d7902c2c2575529ad2a8/6aa6d7902c2c2575529ad2c2`

## Cada coluna é um canal. Escolha pelo assunto e pelo idioma

| Coluna | Canal | listId |
|---|---|---|
| Joao O lobo - A fazer | português, animais perigosos, pets, Amazônia, Brasil | `ari:cloud:trello::list/workspace/6aa6d7902c2c2575529ad2a8/6aa6d7902c2c2575529ad36e` |
| COLOMBIA | espanhol: marcas no mercado da Colômbia, mistérios históricos (maias, incas) | `ari:cloud:trello::list/workspace/6aa6d7902c2c2575529ad2a8/6aa76a66c02594da9dc6e1cd` |
| Dr. Insect | insetos | `ari:cloud:trello::list/workspace/6aa6d7902c2c2575529ad2a8/6aa6d7902c2c2575529ad36f` |
| UK mercado | inglês, marcas/alimentos no Reino Unido | `ari:cloud:trello::list/workspace/6aa6d7902c2c2575529ad2a8/6ab4452744caae961603648b` |
| Canada mercado | inglês, marcas/alimentos no Canadá | `ari:cloud:trello::list/workspace/6aa6d7902c2c2575529ad2a8/6aa7ee2305563fbd6d985ae7` |
| Australia mercado | inglês, marcas/alimentos na Austrália | `ari:cloud:trello::list/workspace/6aa6d7902c2c2575529ad2a8/6ab445eac61ea42f48f90031` |

- O país citado no título manda (Canada, UK/Britain, Australia, Colombia).
- Insetos vão para Dr. Insect, a não ser que o título seja do estilo do Joao O lobo (português, ranking de animais
  perigosos do Brasil) — na dúvida entre as duas, olhe os cartões da coluna (`trelloReadList` get) e escolha a mais
  parecida.
- Se nenhuma coluna servir, pergunte antes de criar.
- Se o usuário disser o canal ("Canada: título — link"), use o que ele disse.

## Como criar

Ferramenta `trelloWriteCard`, `action: "create"`, `listId` da tabela, `name` = título, `desc` = link, `pos: "top"`.
Se as ferramentas do Trello estiverem adiadas, carregue com ToolSearch (`trelloWriteCard`). Se a coluna sumiu ou
mudou de nome, liste de novo com `trelloReadList` (`list_by_board`) e atualize esta tabela.

Depois, responda em uma linha: em qual coluna entrou e o link do cartão. Vários títulos e links na mesma mensagem:
um cartão para cada.
